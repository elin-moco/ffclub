foxCam
======

foxCam is a webApp that can run on almost all platforms, especially Firefox OS.
